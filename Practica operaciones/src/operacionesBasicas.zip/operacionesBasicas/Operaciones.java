
package operacionesBasicas;

public interface Operaciones {

    public float Suma(float x, float y);
    public float Resta(float x, float y);
    public float Desv_Estand(float [] x);
    public int Factorial(int x);
    public int Fibonacci(int x);
    public float Multiplicacion(float x, float y);
    public float Division(float x, float y);
    public float Promedio(float [] x);
    public float MaxNum(float [] x);
    public int ParoImpar(int x);

}
